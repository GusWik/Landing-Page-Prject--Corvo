<div class="wrapper">
    <!--
    <div class="main-banner-slider">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel offers-banner owl-theme owl-loaded owl-drag">
                        <div class="owl-stage-outer">
                            <div class="owl-stage" style="transform: translate3d(-1600px, 0px, 0px); transition: all 0.25s ease 0s; width: 4400px;">
                                <div class="owl-item cloned" style="width: 370px; margin-right: 30px;"><div class="item">
                                    <div class="offer-item">
                                        <div class="offer-item-img">
                                            <div class="gambo-overlay"></div>
                                            <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/banners/offer-3.jpg" alt="">
                                        </div>
                                        <div class="offer-text-dt">
                                            <div class="offer-top-text-banner">
                                                <p>3% Off</p>
                                                <div class="top-text-1">Hot Deals on New Items</div>
                                                <span>Daily Essentials Eggs &amp; Dairy</span>
                                            </div>
                                            <a href="#" class="Offer-shop-btn hover-btn">Shop Now</a>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                                <div class="owl-item cloned" style="width: 370px; margin-right: 30px;">
                                    <div class="item">
                                        <div class="offer-item">
                                            <div class="offer-item-img">
                                                <div class="gambo-overlay"></div>
                                                <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/banners/offer-4.jpg" alt="">
                                            </div>
                                            <div class="offer-text-dt">
                                                <div class="offer-top-text-banner">
                                                    <p>2% Off</p>
                                                    <div class="top-text-1">Buy More &amp; Save More</div>
                                                    <span>Beverages</span>
                                                </div>
                                                <a href="#" class="Offer-shop-btn hover-btn">Shop Now</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item cloned" style="width: 370px; margin-right: 30px;">
                                    <div class="item">
                                        <div class="offer-item">
                                            <div class="offer-item-img">
                                                <div class="gambo-overlay"></div>
                                                <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/banners/offer-5.jpg" alt="">
                                            </div>
                                            <div class="offer-text-dt">
                                                <div class="offer-top-text-banner">
                                                    <p>3% Off</p>
                                                    <div class="top-text-1">Buy More &amp; Save More</div>
                                                    <span>Nuts &amp; Snacks</span>
                                                </div>
                                                <a href="#" class="Offer-shop-btn hover-btn">Shop Now</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item" style="width: 370px; margin-right: 30px;">
                                    <div class="item">
                                        <div class="offer-item">
                                            <div class="offer-item-img">
                                                <div class="gambo-overlay"></div>
                                                <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/banners/offer-1.jpg" alt="">
                                            </div>
                                            <div class="offer-text-dt">
                                                <div class="offer-top-text-banner">
                                                <p>6% Off</p>
                                                <div class="top-text-1">Buy More &amp; Save More</div>
                                                    <span>Fresh Vegetables</span>
                                                </div>
                                                <a href="#" class="Offer-shop-btn hover-btn">Shop Now</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 370px; margin-right: 30px;">
                                    <div class="item">
                                        <div class="offer-item">
                                            <div class="offer-item-img">
                                                <div class="gambo-overlay"></div>
                                                <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/banners/offer-2.jpg" alt="">
                                            </div>
                                            <div class="offer-text-dt">
                                                <div class="offer-top-text-banner">
                                                    <p>5% Off</p>
                                                    <div class="top-text-1">Buy More &amp; Save More</div>
                                                    <span>Fresh Fruits</span>
                                                </div>
                                                <a href="#" class="Offer-shop-btn hover-btn">Shop Now</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 370px; margin-right: 30px;">
                                    <div class="item">
                                        <div class="offer-item">
                                            <div class="offer-item-img">
                                                <div class="gambo-overlay"></div>
                                                <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/banners/offer-3.jpg" alt="">
                                             </div>
                                            <div class="offer-text-dt">
                                                <div class="offer-top-text-banner">
                                                    <p>3% Off</p>
                                                    <div class="top-text-1">Hot Deals on New Items</div>
                                                    <span>Daily Essentials Eggs &amp; Dairy</span>
                                                </div>
                                                <a href="#" class="Offer-shop-btn hover-btn">Shop Now</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 370px; margin-right: 30px;">
                                    <div class="item">
                                        <div class="offer-item">
                                            <div class="offer-item-img">
                                                <div class="gambo-overlay"></div>
                                                <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/banners/offer-4.jpg" alt="">
                                            </div>
                                            <div class="offer-text-dt">
                                                <div class="offer-top-text-banner">
                                                    <p>2% Off</p>
                                                    <div class="top-text-1">Buy More &amp; Save More</div>
                                                    <span>Beverages</span>
                                                </div>
                                                <a href="#" class="Offer-shop-btn hover-btn">Shop Now</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item cloned" style="width: 370px; margin-right: 30px;">
                                    <div class="item">
                                        <div class="offer-item">
                                            <div class="offer-item-img">
                                                <div class="gambo-overlay"></div>
                                                <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/banners/offer-3.jpg" alt="">
                                            </div>
                                            <div class="offer-text-dt">
                                                <div class="offer-top-text-banner">
                                                    <p>3% Off</p>
                                                    <div class="top-text-1">Hot Deals on New Items</div>
                                                    <span>Daily Essentials Eggs &amp; Dairy</span>
                                                </div>
                                                <a href="#" class="Offer-shop-btn hover-btn">Shop Now</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="owl-nav disabled">
                            <button type="button" role="presentation" class="owl-prev"><span aria-label="Previous">←</span></button>
                            <button type="button" role="presentation" class="owl-next"><span aria-label="Next">→</span></button>
                        </div>
                        <div class="owl-dots disabled"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    -->

    <div class="section145">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-title-tt">
                        <div class="main-title-left">
                            <h2>Kategori Produk</h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="owl-carousel cate-slider owl-theme owl-loaded owl-drag">

                        <div class="owl-stage-outer">
                            <div class="owl-stage" style="transform: translate3d(-1200px, 0px, 0px); transition: all 0s ease 0s; width: 4600px;">  
                                <?php foreach ($dataKategori as $key => $vk) {?>
                                <div class="owl-item" style="width: 170px; margin-right: 30px;">
                                    <div class="item">
                                        <a href="<?= base_url('front/dashboard/produkKategori/').$vk->kategori_id;?>" class="category-item">
                                            <div class="cate-img">
                                                <img src="<?= base_url().$vk->icon;?>" alt="">
                                            </div>
                                            <h4> <?= $vk->nama_kategori?> </h4>
                                        </a>
                                    </div>
                                </div>
                                <?php }?>
                            </div>
                        </div>
                        <div class="owl-nav">
                            <button type="button" role="presentation" class="owl-prev"><i class="uil uil-angle-left"></i></button>
                            <button type="button" role="presentation" class="owl-next"><i class="uil uil-angle-right"></i></button>
                        </div>
                        <div class="owl-dots disabled"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="section145">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-title-tt">
                        <div class="main-title-left">
                            <span>For You</span>
                            <h2>Produk</h2>
                        </div>
                        <a href="<?= base_url('front/dashboard/produk');?>" class="see-more-btn">See All</a>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="owl-carousel featured-slider owl-theme owl-loaded owl-drag">
                        <div class="owl-stage-outer">
                            <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 2360px;">
                                <?php foreach ($dataProduk as $key => $vp) {?>
                                <div class="owl-item active" style="width: 285px; margin-right: 10px;">
                                    <div class="item">
                                        <div class="product-item">
                                            <a href="<?= base_url('front/dashboard/detailProduk/').$vp->produk_id;?>" class="product-img">
                                                <img src="<?= base_url().$vp->gambar;?>" alt="">
                                                <div class="product-absolute-options">
                                                    <span class="like-icon" title="wishlist"></span>
                                                </div>
                                            </a>
                                            <div class="product-text-dt">
                                                <?php if($vp->stok > 5){?>
                                                <p>Available<span>(In Stock)</span></p>
                                                <?php }else{?>
                                                    <p>Stok<span><?= $vp->stok?></span></p>
                                                <?php }?>
                                                <h4><?= $vp->nama_produk?></h4>
                                                <div class="product-price"><?= number_format($vp->harga)?></div>
                                                <div class="qty-cart">
                                                    <form method="post" action="<?= base_url('front/dashboard/addCart/');?>" style="width: 100%;">
                                                        <div class="quantity buttons_added">
                                                            <input type="hidden" name="id_produk" value="<?= $vp->produk_id?>">
                                                            <input type="button" value="-" class="minus minus-btn">
                                                            <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                            <input type="button" value="+" class="plus plus-btn">
                                                        </div>
                                                        <button type="submit" class="cart-checkout-btn hover-btn" style="float:right;"> <i class="uil uil-shopping-cart-alt"></i> Add to Cart</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php }?>
                            </div>
                        </div>
                        <div class="owl-nav">
                            <button type="button" role="presentation" class="owl-prev disabled"><i class="uil uil-angle-left"></i></button>
                            <button type="button" role="presentation" class="owl-next"><i class="uil uil-angle-right"></i></button>
                        </div>
                        <div class="owl-dots disabled"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--
    <div class="section145">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-title-tt">
                        <div class="main-title-left">
                            <span>Offers</span>
                            <h2>Best Values</h2>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <a href="#" class="best-offer-item">
                        <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/best-offers/offer-1.jpg" alt="">
                    </a>
                </div>
                <div class="col-lg-4 col-md-6">
                    <a href="#" class="best-offer-item">
                        <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/best-offers/offer-2.jpg" alt="">
                    </a>
                </div>
                <div class="col-lg-4 col-md-6">
                    <a href="#" class="best-offer-item offr-none">
                        <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/best-offers/offer-3.jpg" alt="">
                        <div class="cmtk_dt">
                            <div class="product_countdown-timer offer-counter-text" data-countdown="2021/01/06">00 days 00:00:00</div>
                        </div>
                    </a>
                </div>
                <div class="col-md-12">
                    <a href="#" class="code-offer-item">
                        <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/best-offers/offer-4.jpg" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>


    <div class="section145">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-title-tt">
                        <div class="main-title-left">
                            <span>For You</span>
                            <h2>Fresh Vegetables &amp; Fruits</h2>
                        </div>
                        <a href="#" class="see-more-btn">See All</a>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="owl-carousel featured-slider owl-theme owl-loaded owl-drag">
                        <div class="owl-stage-outer">
                            <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 2360px;">
                                <div class="owl-item active" style="width: 285px; margin-right: 10px;">
                                    <div class="item">
                                        <div class="product-item">
                                            <a href="https://gambolthemes.net/html-items/gambo_supermarket_demo/single_product_view.html" class="product-img">
                                                <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/product/img-11.jpg" alt="">
                                                <div class="product-absolute-options">
                                                    <span class="offer-badge-1">6% off</span>
                                                    <span class="like-icon" title="wishlist"></span>
                                                </div>
                                            </a>
                                            <div class="product-text-dt">
                                                <p>Available<span>(In Stock)</span></p>
                                                <h4>Product Title Here</h4>
                                                <div class="product-price">$12 <span>$15</span></div>
                                                <div class="qty-cart">
                                                    <div class="quantity buttons_added">
                                                        <input type="button" value="-" class="minus minus-btn">
                                                        <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                        <input type="button" value="+" class="plus plus-btn">
                                                    </div>
                                                    <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item" style="width: 285px; margin-right: 10px;">
                                    <div class="item">
                                        <div class="product-item">
                                            <a href="https://gambolthemes.net/html-items/gambo_supermarket_demo/single_product_view.html" class="product-img">
                                                <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/product/img-3.jpg" alt="">
                                                <div class="product-absolute-options">
                                                    <span class="offer-badge-1">3% off</span>
                                                    <span class="like-icon" title="wishlist"></span>
                                                </div>
                                            </a>
                                            <div class="product-text-dt">
                                                <p>Available<span>(In Stock)</span></p>
                                                <h4>Product Title Here</h4>
                                                <div class="product-price">$8 <span>$10</span></div>
                                                <div class="qty-cart">
                                                    <div class="quantity buttons_added">
                                                        <input type="button" value="-" class="minus minus-btn">
                                                        <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                        <input type="button" value="+" class="plus plus-btn">
                                                    </div>
                                                    <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="owl-nav">
                            <button type="button" role="presentation" class="owl-prev disabled"><i class="uil uil-angle-left"></i></button>
                            <button type="button" role="presentation" class="owl-next"><i class="uil uil-angle-right"></i></button>
                        </div>
                        <div class="owl-dots disabled"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="section145">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-title-tt">
                        <div class="main-title-left">
                            <span>For You</span>
                            <h2>Added New Products</h2>
                        </div>
                        <a href="#" class="see-more-btn">See All</a>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="owl-carousel featured-slider owl-theme owl-loaded owl-drag">
                        <div class="owl-stage-outer">
                            <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 2360px;">
                                <div class="owl-item active" style="width: 285px; margin-right: 10px;">
                                    <div class="item">
                                        <div class="product-item">
                                            <a href="#" class="product-img">
                                                <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/product/img-10.jpg" alt="">
                                                <div class="product-absolute-options">
                                                    <span class="offer-badge-1">New</span>
                                                    <span class="like-icon" title="wishlist"></span>
                                                </div>
                                            </a>
                                            <div class="product-text-dt">
                                                <p>Available<span>(In Stock)</span></p>
                                                <h4>Product Title Here</h4>
                                                <div class="product-price">$12 <span>$15</span></div>
                                                <div class="qty-cart">
                                                    <div class="quantity buttons_added">
                                                        <input type="button" value="-" class="minus minus-btn">
                                                        <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                        <input type="button" value="+" class="plus plus-btn">
                                                    </div>
                                                    <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item" style="width: 285px; margin-right: 10px;">
                                    <div class="item">
                                        <div class="product-item">
                                            <a href="https://gambolthemes.net/html-items/gambo_supermarket_demo/single_product_view.html" class="product-img">
                                                <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/product/img-6.jpg" alt="">
                                                <div class="product-absolute-options">
                                                    <span class="offer-badge-1">New</span>
                                                    <span class="like-icon" title="wishlist"></span>
                                                </div>
                                            </a>
                                            <div class="product-text-dt">
                                                <p>Available<span>(In Stock)</span></p>
                                                <h4>Product Title Here</h4>
                                                <div class="product-price">$8 <span>8.75</span></div>
                                                <div class="qty-cart">
                                                    <div class="quantity buttons_added">
                                                        <input type="button" value="-" class="minus minus-btn">
                                                        <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                        <input type="button" value="+" class="plus plus-btn">
                                                    </div>
                                                    <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="owl-nav">
                            <button type="button" role="presentation" class="owl-prev disabled"><i class="uil uil-angle-left"></i></button>
                            <button type="button" role="presentation" class="owl-next"><i class="uil uil-angle-right"></i></button>
                        </div>
                        <div class="owl-dots disabled"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    -->
</div>
<footer class="footer">
    <div class="footer-first-row">
        <div class="container">
            <div class="row">
                <div class="copyright-text">
                    <i class="uil uil-copyright"></i>Copyright 2020 <b>Gambolthemes</b> . All rights reserved
                </div>
            </div>
        </div>
    </div>
</footer>