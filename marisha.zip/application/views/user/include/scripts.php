
<div id="category_model" class="header-cate-model main-gambo-model modal fade" tabindex="-1" role="dialog" aria-modal="false">
    <div class="modal-dialog category-area" role="document">
        <div class="category-area-inner">
            <div class="modal-header">
                <button type="button" class="close btn-close" data-dismiss="modal" aria-label="Close">
                    <i class="uil uil-multiply"></i>
                </button>
            </div>
            <div class="category-model-content modal-content">
                <div class="cate-header">
                    <h4>Select Category</h4>
                </div>
                <ul class="category-by-cat">
                    <?php $dataKategorinya =  $this->db->query("SELECT * FROM tb_kategori")->result();
                    foreach ($dataKategorinya as $key => $vkkg) { ?>
                    <li>
                        <a href="<?= base_url('front/dashboard/produkKategori/').$vkkg->kategori_id;?>" class="single-cat-item">
                            <div class="icon">
                                <img src="<?= base_url().$vkkg->icon?>" alt="">
                            </div>
                            <div class="text"> <?= $vkkg->nama_kategori?> </div>
                        </a>
                    </li>
                    <?php }?>
                </ul>
            </div>
        </div>
    </div>
</div>

<div id="search_model" class="header-cate-model main-gambo-model modal fade" tabindex="-1" role="dialog" aria-modal="false">
    <div class="modal-dialog search-ground-area" role="document">
        <div class="category-area-inner">
            <div class="modal-header">
                <button type="button" class="close btn-close" data-dismiss="modal" aria-label="Close">
                    <i class="uil uil-multiply"></i>
                </button>
            </div>
            <div class="category-model-content modal-content">
                <div class="search-header">
                    <form action="#">
                        <input type="search" placeholder="Search for products...">
                        <button type="submit"><i class="uil uil-search"></i></button>
                    </form>
                </div>
                <div class="search-by-cat">
                    <a href="#" class="single-cat">
                        <div class="icon">
                            <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/category/icon-1.svg" alt="">
                        </div>
                        <div class="text">
                            Fruits and Vegetables
                        </div>
                    </a>
                    <a href="#" class="single-cat">
                        <div class="icon">
                            <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/category/icon-2.svg" alt="">
                        </div>
                        <div class="text"> Grocery &amp; Staples </div>
                    </a>
                    <a href="#" class="single-cat">
                        <div class="icon">
                            <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/category/icon-3.svg" alt="">
                        </div>
                        <div class="text"> Dairy &amp; Eggs </div>
                    </a>
                    <a href="#" class="single-cat">
                        <div class="icon">
                            <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/category/icon-4.svg" alt="">
                        </div>
                        <div class="text"> Beverages </div>
                    </a>
                    <a href="#" class="single-cat">
                        <div class="icon">
                            <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/category/icon-5.svg" alt="">
                        </div>
                        <div class="text"> Snacks </div>
                    </a>
                    <a href="#" class="single-cat">
                        <div class="icon">
                            <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/category/icon-6.svg" alt="">
                        </div>
                        <div class="text"> Home Care </div>
                    </a>
                    <a href="#" class="single-cat">
                        <div class="icon">
                            <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/category/icon-7.svg" alt="">
                        </div>
                        <div class="text"> Noodles &amp; Sauces </div>
                    </a>
                    <a href="#" class="single-cat">
                        <div class="icon">
                            <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/category/icon-8.svg" alt="">
                        </div>
                        <div class="text"> Personal Care </div>
                    </a>
                    <a href="#" class="single-cat">
                        <div class="icon">
                            <img src="https://gambolthemes.net/html-items/gambo_supermarket_demo/images/category/icon-9.svg" alt="">
                        </div>
                        <div class="text"> Pet Care </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?= base_url('assets_front/gombo/js/');?>jquery-3.3.1.min.js"></script>
<script src="<?= base_url('assets_front/gombo/js/');?>bootstrap.bundle.min.js"></script>
<script src="<?= base_url('assets_front/gombo/js/');?>owl.carousel.js"></script>
<script src="<?= base_url('assets_front/gombo/js/');?>semantic.min.js"></script>
<script src="<?= base_url('assets_front/gombo/js/');?>jquery.countdown.min.js"></script>
<script src="<?= base_url('assets_front/gombo/js/');?>custom.js"></script>
<script src="<?= base_url('assets_front/gombo/js/');?>offset_overlay.js"></script>
<script src="<?= base_url('assets_front/gombo/js/');?>night-mode.js"></script>