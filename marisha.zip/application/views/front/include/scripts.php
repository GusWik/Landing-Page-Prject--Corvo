 <!-- jquery latest version -->
<script src="<?= base_url('assets_front/')?>js/vendor/jquery-3.2.1.min.js"></script>
<!-- Bootstrap framework js -->
<script src="<?= base_url('assets_front/')?>js/bootstrap.min.js"></script>
<!-- All js plugins included in this file. -->
<script src="<?= base_url('assets_front/')?>js/plugins.js"></script>
<script src="<?= base_url('assets_front/')?>js/slick.min.js"></script>
<script src="<?= base_url('assets_front/')?>js/owl.carousel.min.js"></script>
<!-- Waypoints.min.js. -->
<script src="<?= base_url('assets_front/')?>js/waypoints.min.js"></script>
<!-- Main js file that contents all jQuery plugins activation. -->
<script src="<?= base_url('assets_front/')?>js/main.js"></script>