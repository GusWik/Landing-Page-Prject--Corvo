<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=9">
    <meta name="description" content="Gambolthemes">
    <meta name="author" content="Gambolthemes">
    <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('uploads/logo.png');?>">
    <title>Bako - Mart</title>

    <link rel="icon" type="image/png" href="https://gambolthemes.net/html-items/gambo_supermarket_demo/https://gambolthemes.net/html-items/gambo_supermarket_demo/images/fav.png">

    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href='<?= base_url("assets_front/gombo/css/")?>unicons.css' rel='stylesheet'>
    <link href="<?= base_url('assets_front/gombo/css/')?>style.css" rel="stylesheet">
    <link href="<?= base_url('assets_front/gombo/css/')?>responsive.css" rel="stylesheet">
    <link href="<?= base_url('assets_front/gombo/css/')?>night-mode.css" rel="stylesheet">

    <link href="<?= base_url('assets_front/gombo/css/')?>all.min.css" rel="stylesheet">
    <link href="<?= base_url('assets_front/gombo/css/')?>owl.carousel.css" rel="stylesheet">
    <link href="<?= base_url('assets_front/gombo/css/')?>owl.theme.default.min.css" rel="stylesheet">
    <link href="<?= base_url('assets_front/gombo/css/')?>bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets_front/gombo/css/')?>semantic.min.css">
</head>
