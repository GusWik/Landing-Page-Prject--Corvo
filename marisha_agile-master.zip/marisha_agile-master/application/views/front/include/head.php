<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>Toko Ridwan</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Place favicon.ico in the root directory -->
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
<link rel="apple-touch-icon" href="apple-touch-icon.png">


<!-- All css files are included here. -->
<!-- Bootstrap fremwork main css -->
<link rel="stylesheet" href="<?= base_url('assets_front/')?>css/bootstrap.min.css">
<!-- Owl Carousel min css -->
<link rel="stylesheet" href="<?= base_url('assets_front/')?>css/owl.carousel.min.css">
<link rel="stylesheet" href="<?= base_url('assets_front/')?>css/owl.theme.default.min.css">
<!-- This core.css file contents all plugings css file. -->
<link rel="stylesheet" href="<?= base_url('assets_front/')?>css/core.css">
<!-- Theme shortcodes/elements style -->
<link rel="stylesheet" href="<?= base_url('assets_front/')?>css/shortcode/shortcodes.css">
<!-- Theme main style -->
<link rel="stylesheet" href="<?= base_url('assets_front/')?>style.css">
<!-- Responsive css -->
<link rel="stylesheet" href="<?= base_url('assets_front/')?>css/responsive.css">
<!-- User style -->
<link rel="stylesheet" href="<?= base_url('assets_front/')?>css/custom.css">
<script src="<?= base_url('assets_front/')?>js/vendor/modernizr-3.5.0.min.js"></script>