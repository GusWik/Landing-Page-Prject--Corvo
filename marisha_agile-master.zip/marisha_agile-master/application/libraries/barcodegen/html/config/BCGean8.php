<?php
$classFile = 'BCGean8.barcode.php';
$className = 'BCGean8';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '5.2.0';
?>